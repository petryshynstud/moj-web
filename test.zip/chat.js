const PROXY_URL = "https://moj-web-gemini-proxy.artem-proxy.workers.dev";

// Додаємо ?v=2, щоб змусити браузер завантажити фото заново (скинути кеш)
const POSTAVY = {
  jakub: {
    id: "jakub",
    name: "Jakub",
    tagline: "Študent IT & AI • Online",
    avatar: "img/jakub.png?v=2", 
    time: "14:20",
    preview: "Super, v stredu o 17:00 mi to vyhovuje...",
    skills: "Si Jakub, skúsený softvérový inženýr. Tvoje špecializácie: ladenie, code review, architektúra. Odpovedaj konkrétne, ukáž kód a vysvetli PREČO.",
    welcome: "Ahoj Artem! Videl som tvoj profil v Matching Hube. Zaoberáš sa Pythonom a základmi AI, mohol by si mi poradiť s jedným projektom?"
  },
  timea: {
    id: "timea",
    name: "Timea",
    tagline: "Študentka IT • Online",
    avatar: "img/timea.png?v=2", 
    time: "Včera",
    preview: "Ďakujem za tipy k responzívnemu CSS!",
    skills: "Si Timea, študentka psychológie. Tvoje špecializácie: aktívne počúvanie, motivácia. Buď empatická, ale vecná. NIKDY nestanovuj diagnózy.",
    welcome: "Ahoj! Ako sa dnes cítiš? Môžeme sa o tom porozprávať."
  },
  petr: {
    id: "petr",
    name: "Petr",
    tagline: "Študent / UX & UI dizajnér",
    avatar: "img/petr.png?v=2",
    time: "Pondelok",
    preview: "Pošlem ti návrh vo Figme na spätnú...",
    skills: "Si Petr, produktový dizajnér. Tvoje špecializácie: UX výskum, vizuálna hierarchia, typografia. Buď konkrétny (HEX farby, px/rem).",
    welcome: "Ahoj! Potrebuješ pomoc s UX, farbami alebo layoutom?"
  }
};

let aktualnaPostava = "jakub";
let historia = [];
let odosielaSa = false;

const chatListEl = document.getElementById("chatList");
const messagesArea = document.getElementById("messagesArea");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const headerName = document.getElementById("headerName");
const headerAvatar = document.getElementById("headerAvatar");
const headerStatus = document.getElementById("headerStatus");
const btnProfile = document.getElementById("btnProfile");

function getFallbackAvatar(name) {
  return `https://ui-avatars.com/api/?name=${name.charAt(0)}&background=2563eb&color=fff&size=128&bold=true`;
}

function zostavitLinkedInBlok() {
  let ctx = { url: "", role: "", skills: "" };
  try {
    const raw = localStorage.getItem("linkedin_context_v1");
    if (raw) ctx = { ...ctx, ...JSON.parse(raw) };
    const zReg = localStorage.getItem("linkedin_url");
    if (!ctx.url && zReg) ctx.url = zReg;
  } catch {}
  if (!ctx.url && !ctx.role && !ctx.skills) return "";
  let text = "\n\nKontext o používateľovi:\n";
  if (ctx.url) text += `- URL: ${ctx.url}\n`;
  if (ctx.role) text += `- Rola: ${ctx.role}\n`;
  if (ctx.skills) text += `- Zručnosti: ${ctx.skills}\n`;
  return text;
}

function vykreslitZoznam() {
  chatListEl.innerHTML = "";
  Object.values(POSTAVY).forEach(postava => {
    const isActive = postava.id === aktualnaPostava;
    const item = document.createElement("div");
    item.className = `chat-contact ${isActive ? "active" : ""}`;
    item.onclick = () => prepnutPostavu(postava.id);

    item.innerHTML = `
      <img src="${postava.avatar}" class="chat-contact-avatar" alt="${postava.name}" onerror="this.onerror=null; this.src='${getFallbackAvatar(postava.name)}'">
      <div class="chat-contact-info">
        <div class="chat-contact-top">
          <span class="chat-contact-name">${postava.name}</span>
          <span class="chat-contact-time">${postava.time}</span>
        </div>
        <div class="chat-contact-preview">${postava.preview}</div>
      </div>
    `;
    chatListEl.appendChild(item);
  });
}

function pridatSpravu(rola, text) {
  const row = document.createElement("div");
  row.className = `chat-msg-row ${rola}`;
  const bubble = document.createElement("div");
  bubble.className = "chat-bubble";
  bubble.textContent = text;
  row.appendChild(bubble);
  messagesArea.appendChild(row);
  messagesArea.scrollTop = messagesArea.scrollHeight;
  return bubble;
}

async function zavolatAI(text) {
  const postava = POSTAVY[aktualnaPostava];
  historia.push({ role: "user", parts: [{ text: text }] });

  const systemInstruction = {
    parts: [{ text: postava.skills + zostavitLinkedInBlok() }]
  };

  const resp = await fetch(PROXY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ systemInstruction, contents: historia })
  });

  if (!resp.ok) {
    historia.pop();
    throw new Error(`Chyba API: ${resp.status}`);
  }

  const data = await resp.json();
  const odpovedText = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join("") || "Prepáč, nepodarilo sa získať odpoveď.";
  
  historia.push({ role: "model", parts: [{ text: odpovedText }] });
  return odpovedText;
}

function prepnutPostavu(id) {
  if (id === aktualnaPostava) return;
  aktualnaPostava = id;
  historia = [];
  
  const postava = POSTAVY[id];
  
  headerName.textContent = postava.name;
  headerStatus.textContent = postava.tagline;
  
  // Примусово встановлюємо фото в шапку
  headerAvatar.src = postava.avatar;
  headerAvatar.onerror = function() {
    this.onerror = null;
    this.src = getFallbackAvatar(postava.name);
  };
  
  btnProfile.onclick = () => window.location.href = `profil-${postava.name.toLowerCase()}.html`;

  vykreslitZoznam();

  messagesArea.innerHTML = `<div class="chat-date"><span>Dnes</span></div>`;
  pridatSpravu("model", postava.welcome);
  
  userInput.focus();
}

sendBtn.addEventListener("click", async () => {
  const text = userInput.value.trim();
  if (!text || odosielaSa) return;

  userInput.value = "";
  pridatSpravu("user", text);

  odosielaSa = true;
  sendBtn.disabled = true;
  
  const loadingBubble = pridatSpravu("model", "Píše...");
  
  try {
    const odpoved = await zavolatAI(text);
    loadingBubble.textContent = odpoved;
  } catch (err) {
    loadingBubble.textContent = `⚠ ${err.message}`;
    loadingBubble.style.color = "red";
  } finally {
    odosielaSa = false;
    sendBtn.disabled = false;
    userInput.focus();
  }
});

userInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    sendBtn.click();
  }
});

// Старт: примусово завантажуємо першого, щоб заповнити шапку
vykreslitZoznam();
aktualnaPostava = ""; // Скидаємо, щоб функція спрацювала
prepnutPostavu("jakub");